<?php 
include_once('Crud.php');
$crud = new Crud();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	$id = $_GET["id"];
	$sql = "DELETE FROM meal_type WHERE id=$id";
	$crud->update($sql);
	echo "You have just deleted post id " . $id; ?>
	<a href="<?php echo $crud->homedir ?>">Click here to go back to the homepage</a>
	<?php
	} else{
	header("Location:$crud->homedir");
	}
?>