
<?php
include_once('Crud.php');
$crud = new Crud();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
 
 	
	$meal = $_POST['meal'];
	$in1 = $_POST['ingredient1'];
	$in2 = $_POST['ingredient2'];
	$in3 = $_POST['ingredient3'];	
	$in4 = $_POST['ingredient4'];
	$in5 = $_POST['ingredient5'];
	$in6 = $_POST['ingredient6'];
	$des = $_POST['description'];
	$rec = $_POST['recipe'];
	$ins = $_POST['instructions'];	
	$img = $_POST['image'];
	
		
	
	$sql = "INSERT INTO meal_type (meal, ingredient1, ingredient2, ingredient3, ingredient4, ingredient5, ingredient6, img, description, recipe, instructions)
	VALUES ('$meal', '$in1', '$in2', '$in3', '$in4', '$in5', '$in6', '$img', '$des', '$rec', '$ins')";
	$result = $crud->write($sql);
	$_POST = array();
	?>
	
	<a href="<?php echo $crud->homedir ?>create.php">Add more items</a><br>	
	<a href="<?php echo $crud->homedir ?>index.php">Click here to go back to the homepage</a>
	<?php
	exit(); 
}
?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Add new banana</title>
</head>
<body>

<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">


    <p>
        <label for="meal">Meal:</label>
        <input type="text" name="meal" required>
    </p>
<p>
        <label for="description">Description:</label><br>
        <textarea type="text" rows="20" cols="40" name="description" required>
		</textarea>
		
    </p>
    <p>
        <label for="ingredient1">Ingredient 1:</label>
        <input type="text" name="ingredient1" required>
    </p>
    <p>
        <label for="ingredient2">Ingredient 2:</label>
        <input type="text" name="ingredient2">
    </p>
<p>
        <label for="ingredient3">Ingredient 3:</label>
        <input type="text" name="ingredient3">
    </p>
<p>
        <label for="ingredient4">Ingredient 4:</label>
        <input type="text" name="ingredient4">
    </p>
<p>
        <label for="ingredient5">Ingredient 5:</label>
        <input type="text" name="ingredient5">
    </p>
<p>
        <label for="ingredient6">Ingredient 6:</label>
        <input type="text" name="ingredient6">
    </p>
<p>
        <label for="recipe">Recipe:</label><br>
        <textarea type="text" rows="20" cols="40" name="recipe" required>
		</textarea>
		
    </p>
<p>
        <label for="instructions">Instructions:</label><br>
        <textarea type="text" rows="20" cols="40" name="instructions" required>
		</textarea>
		
    </p>
    <p>
        <label for="img">Image</label>
        <input type="text" name="image" required>
    </p>
    <input type="submit" value="Submit">
</form>

</body>
</html>