<?php
include_once('Crud.php');
$crud = new Crud();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	$id = $_POST["id"];
	$meal = $_POST["meal"];
	$in1 = $_POST["ingredient1"];
	$in2 = $_POST["ingredient2"];
	$in3 = $_POST["ingredient3"];	
	$in4 = $_POST["ingredient4"];
	$in5 = $_POST["ingredient5"];
	$in6 = $_POST["ingredient6"];
	$des = $_POST["description"];
	$rec = $_POST["recipe"];
	$ins = $_POST["instructions"];
	$img = $_POST["image"];
	
	$sql = "UPDATE meal_type SET meal='$meal', ingredient1='$in1', ingredient2='$in2', ingredient3='$in3', ingredient4='$in4', ingredient5='$in5', ingredient6='$in6', description='$des', recipe='$rec', instructions='$ins', img='$img' WHERE id='$id'";
		
	$crud->update($sql);
	$_POST = array();
	
	header("Location:$crud->homedir/update.php?id=$id");
	} else{
		//fetch data
		$id = $_GET["id"];
		$sql = "SELECT * FROM meal_type WHERE id = $id";
		$result = $crud->read($sql);
	}
?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Edit Meal</title>
</head>
<body>

	<?php
	foreach ($result as $key => $row) {
	?>

	<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">

    <p>
        <label for="id">id:</label>
        <input type="text" name="id" value="<?php echo $row['id']?>">
    </p>

    <p>
        <label for="firstName">Meal:</label>
        <input type="text" name="meal" value="<?php echo $row['meal']?>" required>
    </p>
<p>
        <label for="description">Description:</label><br>
        <textarea type="text" rows="20" cols="40" name="description" required><?php echo $row['description']?>
		</textarea>
		
    </p>
    <p>
        <label for="in1">Ingredient 1:</label>
        <input type="text" name="ingredient1" value="<?php echo $row['ingredient1']?>" required>
    </p>
    <p>
        <label for="in2">Ingredient 2:</label>
        <input type="text" name="ingredient2" value="<?php echo $row['ingredient2']?>" >
    </p>
<p>
        <label for="in3">Ingredient 3:</label>
        <input type="text" name="ingredient3" value="<?php echo $row['ingredient3']?>" >
    </p>
<p>
        <label for="in4">Ingredient 4:</label>
        <input type="text" name="ingredient4" value="<?php echo $row['ingredient4']?>" >
    </p>
<p>
        <label for="in5">Ingredient 5:</label>
        <input type="text" name="ingredient5" value="<?php echo $row['ingredient5']?>" >
    </p>
<p>
        <label for="in6">Ingredient 6:</label>
        <input type="text" name="ingredient6" value="<?php echo $row['ingredient6']?>" >
    </p>
<p>
        <label for="recipe">Recipe:</label><br>
        <textarea type="text" rows="20" cols="40" name="recipe" required><?php echo $row['recipe']?>
		</textarea>
		
    </p>
<p>
        <label for="instructions">Instructions:</label><br>
        <textarea type="text" rows="20" cols="40" name="instructions" required><?php echo $row['instructions']?>
		</textarea>
		
    </p>
    <p>
        <label for="pics">Image</label>
        <input type="text" name="image" value="<?php echo $row['img'] ?>" required>
    </p>
    <input type="submit" value="Submit">
	</form>
	
	<form action="<?php echo $crud->homedir ?>delete.php?id=<?php echo $row['id']?>" method="post">
	<input type="submit" value="Delete">
	</form>

	<?php     
	}
	?>

</body>
</html>