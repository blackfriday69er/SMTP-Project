<?php
    class DbConnection 
    {    
		private $host;
        private $username;
        private $password;
        private $database;
        protected $connection;
		public $homedir;
     
        public function __construct(){
     
		$dbc = parse_ini_file("db.ini");
		$this->host = $dbc['host'];
		$this->username = $dbc['user'];
		$this->password = $dbc['pass'];
		$this->database = $dbc['name'];
		$this->homedir = $dbc['homedir'];
	 
            if (!isset($this->connection)) {
     
                $this->connection = new mysqli($this->host, $this->username, $this->password, $this->database);
     
                if (!$this->connection) {
                    echo 'Cannot connect to database server';
                    exit;
                }            
            }    
			
            return $this->connection;
        }
		
    }
?>