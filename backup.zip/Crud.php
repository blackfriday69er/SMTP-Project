<?php

include_once('DbConnection.php');

class Crud extends DbConnection
{
	public function __construct(){
	parent::__construct();
	}
	    public function read($sql){
 
        $query = $this->connection->query($sql);
  
        $rows = array();
        while ($row = $query->fetch_array()) {
            $rows[] = $row;
        }
        return $rows;
		}
		
		public function write($sql){
 
        $query = $this->connection->query($sql);
    
		}
		
		public function update($sql){
		
        $this->connection->query($sql);
    
		}
}

?>