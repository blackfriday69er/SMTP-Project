<?php
include_once('Crud.php');
$crud = new Crud();
$id = $_GET["id"];
//fetch data
$sql = "SELECT * FROM meal_type WHERE id = $id";
$result = $crud->read($sql);
?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Meal Single</title>
</head>
<body>

	<?php
	foreach ($result as $key => $row) {
	?>
	<div class="items">
	<?php echo $row['meal'] . "<Br>"; ?>
	<?php echo $row['ingredient1'] . "<Br>"; ?>
	<?php echo $row['ingredient2'] . "<Br>"; ?>
	<?php echo $row['ingredient3'] . "<Br>"; ?>
	<?php echo $row['ingredient4'] . "<Br>"; ?>
	<?php echo $row['ingredient5'] . "<Br>"; ?>
	<?php echo $row['ingredient6'] . "<Br>"; ?>
	<?php echo $row['recipe'] . "<Br>"; ?>
	<?php echo $row['instructions'] . "<Br>"; ?>
	<img style='height:150px;width:150px;' src='<?php echo $row['img']; ?>'></img> <br>		
	</div>
	<?php     
	}
	?>

</body>
</html>