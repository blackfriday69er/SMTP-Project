<?php
//crud with database connection
include_once('Crud.php');

$crud = new Crud();

//fetch data
$sql = "SELECT * FROM meal_type";
$result = $crud->read($sql);
?>

<!doctype html>
<html lang="en">
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- CSS -->
	<link rel="stylesheet" href="style.css">
	<title>Meals</title>


<body>
    
	<div>
	
	<ul>
	<li><a href="<?php echo $crud->homedir ?>/create.php">Add item</a></li>
	</ul>
	
	</div>
	
<div class="containter">
	
		<?php
		foreach ($result as $key => $row) {
		?>
	<a href="<?php echo $crud->homedir ?>/single.php/?id=<?php echo $row['id'] ?>">
	<div class="items">
		
		<?php echo $row['meal'] . "<Br>"; ?></a>
		
		<img style='height:150px;width:150px;' src='<?php echo $row['img']; ?>'></img> <br>
		<a href="<?php echo $crud->homedir ?>/update.php/?id=<?php echo $row['id'] ?>">edit</a>
	</div>
	</a>
		<?php     
		}
		?>
	
</div>

</body>
</html>